package doubleLinkedList;

public class ListEmptyException extends Exception {
	public ListEmptyException() {
		super("Error. List is Empty");
	}
}
