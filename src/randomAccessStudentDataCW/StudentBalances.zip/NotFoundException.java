package randomAccessStudentDataCW;

public class NotFoundException extends Exception{
	public NotFoundException(){
		super("not found");
	}

}
