package randomAccessStudentDataCW;

public class InvalidPermissionException extends Exception{
	public InvalidPermissionException (){
		super("invalid supervisor override");
	}

}
