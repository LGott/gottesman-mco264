package SchoolProject;

import java.util.GregorianCalendar;

public class CompletedCourse extends Course {

	private Integer studentID;
	private Grade grade;
	private GregorianCalendar completedDate; // Switch to gregorian Calendar?

	public CompletedCourse(String courseID, String description, int numCredits, String dptID, Integer studentID,
			Grade grade, GregorianCalendar completedDate) {

		super(courseID, description, numCredits, dptID);

		this.studentID = studentID;
		this.grade = grade;
		this.completedDate = completedDate;
	}

	public Integer getStudentID() {
		return studentID;
	}

	public Grade getGrade() {
		return grade;
	}

	public GregorianCalendar getCompletedDate() {
		return completedDate;
	}

}
