package SchoolProject;

import java.io.FileNotFoundException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.Scanner;

public class ManageSchool {

	public static void main(String[] args) throws FileNotFoundException, ParseException {

		School sampleSchool = new School("ELG", new Address("650 West End Ave", "NY", USState.NY, "10025"),
				"2129876543", "C:/Users/Leba Gottesman/Documents/Touro College/DataStructures1/HW/teachers.txt",
				"C:/Users/Leba Gottesman/Documents/Touro College/DataStructures1/HW/students.txt",
				"C:/Users/Leba Gottesman/Documents/Touro College/DataStructures1/HW/departments.txt",
				"C:/Users/Leba Gottesman/Documents/Touro College/DataStructures1/HW/courses.txt");

		Scanner input = new Scanner(System.in);

		int menuChoice = 0;

		menuChoice = menu();
		do {

			switch (menuChoice) {

			case 1: // Ensure there are no duplicates System.out.print(
				System.out.println("Enter ID:");
				Integer ID = input.nextInt();
				System.out.println("Enter First Name:");
				String firstName = input.next();
				System.out.println("Enter Last Name:");
				String lastName = input.next();
				System.out.println("Enter Mid Initial:");
				String midInitial = input.next();
				System.out.println("Enter Street:");
				String street = input.next();
				System.out.println("Enter City:");
				String city = input.next();
				System.out.println("Enter State:");
				String state = input.next();
				System.out.println("Enter Zip:");
				String zip = input.next();
				System.out.println("Enter Phone:");
				String phone = input.next();
				System.out.println("Enter gender:");
				char gender = input.next().charAt(0);
				System.out.println("Enter hireDate:");
				String hireDate = input.next();
				System.out.println("Enter DOB:");
				String dob = input.next();
				System.out.println("Enter Employee Type:");
				String typeEmp = input.next();
				System.out.println("Enter Department ID");
				String dptID = input.next();
				System.out.println("Enter SSN:");
				String ssNum = input.next();
				System.out.println("Enter Degree:");
				String degreeType = input.next();
				System.out.println("Enter major ID:");
				String major = input.next();
				System.out.println("Enter salary:");
				Double salary = input.nextDouble();

				USState stateEnum = sampleSchool.getState(state);
				EmployeeType type = sampleSchool.getType(typeEmp);
				Degree degree = sampleSchool.getDegree(degreeType);
				Major majorID = sampleSchool.getMajor(major);

				Address address = new Address(street, city, stateEnum, zip);

				GregorianCalendar dateHire = sampleSchool.stringToDate(hireDate);
				GregorianCalendar dateBirth = sampleSchool.stringToDate(dob);

				sampleSchool.addTeacher(ID, firstName, lastName, midInitial, address, phone, gender, dateHire,
						dateBirth, type, dptID, ssNum, degree, majorID, salary);
				System.out.println("Teacher Successfully Added.");
				break;

			case 2:

				System.out.println("Enter ID:");
				ID = input.nextInt();
				System.out.println("Enter First Name:");
				firstName = input.next();
				System.out.println("Enter Last Name:");
				lastName = input.next();
				System.out.println("Enter Mid Initial:");
				midInitial = input.next();
				System.out.println("Enter Street:");
				street = input.next();
				System.out.println("Enter City:");
				city = input.next();
				System.out.println("Enter State:");
				state = input.next();
				System.out.println("Enter Zip:");
				zip = input.next();
				System.out.println("Enter Phone:");
				phone = input.next();
				System.out.println("Enter gender:");
				gender = input.next().charAt(0);
				System.out.println("Enter major ID:");
				major = input.next();
				System.out.println("Enter DOB:");
				dob = input.next();
				System.out.println("Enter enrolled Date");
				String enrolledDate = input.next();
				System.out.println("Enter SSN:");
				ssNum = input.next();

				stateEnum = sampleSchool.getState(state);
				majorID = sampleSchool.getMajor(major);

				address = new Address(street, city, stateEnum, zip);

				GregorianCalendar studentDOB = sampleSchool.stringToDate(dob);
				GregorianCalendar dateEnrolled = sampleSchool.stringToDate(enrolledDate);

				sampleSchool.addStudent(ID, firstName, lastName, midInitial, address, phone, gender, majorID,
						studentDOB, dateEnrolled, ssNum);
				System.out.println("Student Successfully Added.\n");
				break;

			case 3:

				System.out.print("Enter course ID:");
				String courseID = input.next();
				System.out.print("Enter course desciption:");
				String description = input.nextLine();
				System.out.print("Enter number of credits:");
				int numCredits = input.nextInt();
				System.out.print("Enter dpt ID:");
				dptID = input.nextLine();

				sampleSchool.addCourse(courseID, description, numCredits, dptID);
				System.out.println("Course added successfully");
				break;

			case 4:

				System.out.print("Enter dpt ID:\n");
				dptID = input.next();
				System.out.print("Enter dpt Name:\n");
				String dptName = input.next();
				System.out.print("Enter dpt location:");
				String dptLocation = input.next();
				System.out.print("Enter phone number:\n");
				phone = input.next();
				System.out.print("Enter fax Number:\n");
				String faxNum = input.next();
				System.out.print("Enter dpt Chairperson:\n");
				String dptChairperson = input.next();

				sampleSchool.addDepartment(dptID, dptName, dptLocation, phone, faxNum, dptChairperson);
				System.out.println("Department added successfully");
				break;

			case 5:

				System.out.print("Enter first name:");
				firstName = input.next();
				System.out.println("\nEnter last name:");
				lastName = input.next();
				sampleSchool.removeTeacher(firstName, lastName);
				break;

			case 6:

				System.out.print("Enter first name:");
				firstName = input.next();
				System.out.println("\nEnter last name:");
				lastName = input.next();
				sampleSchool.removeStudent(firstName, lastName);
				break;

			case 7:

				System.out.print("Enter course ID:");
				courseID = input.next();
				sampleSchool.removeCourse(courseID);
				break;

			case 8:

				System.out.print("Enter teacher ID:");
				Integer teacherID = input.nextInt();
				System.out.print("\nEnter new last name:");
				lastName = input.next();

				sampleSchool.modifyTeacherLastName(teacherID, lastName);
				System.out.println("Teacher successfully modified.");
				break;

			case 9:

				System.out.print("Enter teacher ID:");
				teacherID = input.nextInt();
				System.out.print("\nEnter new Street");
				street = input.next();
				System.out.print("\nEnter new city");
				city = input.next();
				System.out.print("\nEnter new state");
				state = input.next();
				System.out.print("\nEnter new zip");
				zip = input.next();

				USState newState = sampleSchool.getState(state);

				Address newAddress = new Address(street, city, newState, zip);

				sampleSchool.modifyTeacherAddress(teacherID, newAddress);

				break;

			case 10:

				System.out.print("Enter teacher ID:");
				teacherID = input.nextInt();
				System.out.print("\nEnter new Degree:");
				String newDegree = input.next();
				System.out.print("\nEnter new Major:");
				String newMajor = input.next();

				Degree degreeEnum = sampleSchool.getDegree(newDegree);

				Major majorEnum = sampleSchool.getMajor(newMajor);

				sampleSchool.modifyTeacherDegree(teacherID, degreeEnum, majorEnum);

				break;

			case 11:

				System.out.print("Enter teacher ID:");
				teacherID = input.nextInt();
				System.out.print("\nEnter percentage increase:");
				Double increase = input.nextDouble();

				sampleSchool.giveTeacherRaise(teacherID, increase);

				break;

			case 12:

				System.out.print("Enter teacher ID:");
				teacherID = input.nextInt();
				System.out.print("\nEnter new Salary Amount:");
				Double newSalary = input.nextDouble();

				sampleSchool.giveTeacherRaise(teacherID, newSalary);

				break;

			case 13:

				System.out.print("Enter student ID:");
				Integer studentID = input.nextInt();
				System.out.print("\nEnter new last name:");
				lastName = input.next();

				sampleSchool.modifyStudentLastName(studentID, lastName);

				break;

			case 14:

				System.out.print("Enter student ID:");
				studentID = input.nextInt();
				System.out.print("\nEnter new phone number:");
				String number = input.next();

				sampleSchool.modifyStudentPhoneNumber(studentID, number);

				break;

			case 15:

				System.out.print("Enter student ID:");
				studentID = input.nextInt();
				System.out.print("\nEnter course ID:");
				String course = input.nextLine();
				System.out.print("Enter grade of course:");
				String grade = input.next();

				Grade gradeValue = null;
				for (Grade gr : Grade.values()) {
					if (gr.name().equalsIgnoreCase(grade)) {
						gradeValue = gr;
					}
				}

				sampleSchool.addCompletedCourse(studentID, course, gradeValue);

				break;

			case 16:

				System.out.print("Enter student ID:");
				studentID = input.nextInt();

				sampleSchool.getStudentGPA(studentID);

				break;

			case 17:

				System.out.print("Enter student ID:");
				studentID = input.nextInt();
				System.out.println("Enter course ID");
				course = input.next();

				sampleSchool.getGradeofCourse(studentID, course);

				break;

			case 18:

				System.out.print("Enter student ID:");
				studentID = input.nextInt();
				System.out.println("Enter department ID");
				dptID = input.next();

				sampleSchool.getCoursesbyDepartment(studentID, dptID).toString();

				break;

			case 19:

				Grade valueGrade = null;
				System.out.print("Enter student ID:");
				studentID = input.nextInt();
				System.out.println("Enter Grade ");
				grade = input.next();

				for (Grade gr : Grade.values()) {
					if (gr.name().equalsIgnoreCase(grade)) {
						valueGrade = gr;
					}
				}

				sampleSchool.getCoursesbyGrade(studentID, valueGrade).toString();

				break;

			case 20:

				System.out.println(sampleSchool.getTeachersSortedByName().toString());
				break;

			case 21:

				System.out.println(sampleSchool.getTeachers().toString());
				break;

			case 22:

				System.out.println(sampleSchool.getStudents().toString());
				break;

			case 23:

				System.out.println(sampleSchool.getStudentsByName().toString());
				break;

			case 24:

				System.out.print("Enter teacher ID:");
				teacherID = input.nextInt();
				System.out.println("\nEnter course ID: ");
				course = input.next();
				System.out.print("Enter year:");
				Integer year = input.nextInt();
				System.out.println("Enter Semester");
				String semester = input.next();
				System.out.print("Enter Section:");
				String section = input.next();

				Semester semesterCode = null;
				for (Semester sm : Semester.values()) {
					if (sm.name().equalsIgnoreCase(semester)) {
						semesterCode = sm;
					}
				}

				Section sectionType = null;
				for (Section sc : Section.values()) {
					if (sc.name().equalsIgnoreCase(section)) {
						sectionType = sc;
					}
				}

				sampleSchool.addTaughtCourse(teacherID, course, year, semesterCode, sectionType);

				break;

			case 25:

				System.out.print("Enter teacher ID:");
				teacherID = input.nextInt();
				System.out.print("Enter year:");
				year = input.nextInt();
				System.out.println("Enter Semester");
				semester = input.nextLine();

				Semester codeSemester = null;
				for (Semester sm : Semester.values()) {
					if (sm.name().equalsIgnoreCase(semester)) {
						semesterCode = sm;
					}
				}

				sampleSchool.howManyCoursesPerSemester(teacherID, year, codeSemester);

				break;
			case 26:
				ArrayList<Person> teachers = sampleSchool.displayPeople();

				System.out.println(teachers.toString());
			}
			menuChoice = menu();
		} while (menuChoice <= 26);

		input.close();

	}

	public static int menu() {

		Scanner input = new Scanner(System.in);
		int menuChoice = 0;

		System.out.println("Please Choose a Menu Option: \n" + "1. Add Teacher\n " + "2. Add Student\n"
				+ "3. Add Course\n" + "4. Add Department\n" + "5. Remove Teacher\n" + "6. Remove Student\n"
				+ "7. Remove Course\n" + "8. Modify Teacher Last Name\n" + "9. Modify Teacher Address\n"
				+ "10. Modify Teacher Degree\n" + "11. Give Teacher a Raise (Percentage)\n"
				+ "12. Give Teacher a Raise (New Salary amount)\n" + "13. Modify Student Last Name\n"
				+ "14. Modify Student Phone Number\n" + "15. Add Completed Course\n" + "16. View Student GPA\n"
				+ "17. View Grade of Course\n" + "18. View Courses by department\n" + "19. View Courses by Grade\n"
				+ "20. View Teachers sorted by name\n" + "21. View Teachers sorted by ID\n"
				+ "22. View Students sorted by ID\n" + "23. View Students sorted by name\n"
				+ "24. Add a Taught Course for a Specific Teacher\n"
				+ "25. View Taught Course Amount for Specific Teacher\n" + "26. View List of Teachers");

		menuChoice = input.nextInt();

		return menuChoice;
	}

}
