package SchoolProject;

import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.NoSuchElementException;

public class Student extends Person {

	private Major studentMajor;
	private GregorianCalendar enrolledDate;
	private GregorianCalendar dateOfBirth;
	private Double GPA; // Default null
	private Integer creditsEarned; // default 0
	private String SSnum;
	private ArrayList<CompletedCourse> coursesCompleted;

	public Student(Integer ID, String firstName, String lastName, String midInitial, Address address,
			String phoneNumber, char gender, Major studentMajor, GregorianCalendar dateOfBirth,
			GregorianCalendar enrolledDate, String SSnum) {

		// Call the superclass constructor
		super(ID, firstName, lastName, midInitial, address, phoneNumber, gender);

		// To validate if major entered actually exists
		studentMajor = getMajor(studentMajor);

		// If major is not declared, assign it as undecided.

		if (studentMajor == null) {
			this.studentMajor = Major.UDCD;
		}

		if (getMajor(studentMajor) == null) {
			throw new InvalidDataException(); // If major does not exist, throw
												// an exception
		}

		this.studentMajor = studentMajor; // If major exists, assign it to the
											// variable
		this.enrolledDate = new GregorianCalendar(); // Assign todays date as
														// the enrollment date
		this.dateOfBirth = dateOfBirth;
		this.GPA = null;
		this.creditsEarned = 0;
		this.SSnum = SSnum;
		this.coursesCompleted = new ArrayList<CompletedCourse>();

	}

	// Constructor that omits the phone number
	public Student(Integer ID, String firstName, String midInitial, String lastName, Address address, char gender,
			Major studentMajor, GregorianCalendar dateOfBirth, GregorianCalendar enrolledDate, String SSnum) {

		this(ID, firstName, lastName, midInitial, address, null, gender, studentMajor, dateOfBirth, enrolledDate,
				SSnum);

	}

	// Constructor that omits just the mid initial
	public Student(Integer ID, String firstName, String lastName, Address address, String phoneNumber, char gender,
			Major studentMajor, GregorianCalendar dateOfBirth, GregorianCalendar enrolledDate, String SSnum) {

		this(ID, firstName, lastName, null, address, phoneNumber, gender, studentMajor, dateOfBirth, enrolledDate,
				SSnum);

	}

	// Constructor that omits all the optional data
	public Student(Integer ID, String firstName, String lastName, Address address, char gender, Major studentMajor,
			GregorianCalendar dateOfBirth, GregorianCalendar enrolledDate, String SSnum) {

		this(ID, firstName, lastName, null, address, null, gender, studentMajor, dateOfBirth, enrolledDate, SSnum);

	}
	// To validate if the major entered exists

	private static Major getMajor(Major major) {
		for (Major theMajor : Major.values()) {
			if (theMajor == (major)) {
				return theMajor;
			}
		}
		return null;
	}

	// Getters and setters. only Major, GPA, and credits earned may be modified
	public Major getStudentMajor() {
		return studentMajor;
	}

	public void setStudentMajor(Major studentMajor) {
		this.studentMajor = studentMajor;
	}

	public Double getGPA() {
		return GPA;
	}

	public void setGPA(Double gPA) {

		// If GPA is less than 0.0 or greater than 4.0, throw an exception
		if ((gPA < 0.0) || (gPA > 4.0)) {

			throw new InvalidDataException();
		} else {
			GPA = gPA;
		}
	}

	public Integer getCreditsEarned() {
		return creditsEarned;
	}

	public void setCreditsEarned(Integer creditsEarned) {

		// Validate credit data
		if ((creditsEarned < 0.0) || (creditsEarned > 120.00)) {
			throw new InvalidDataException();
		}

		else {
			this.creditsEarned = creditsEarned;
		}
	}

	public GregorianCalendar getEnrolledDate() {
		return enrolledDate;
	}

	public GregorianCalendar getDateOfBirth() {
		return dateOfBirth;
	}

	public String getSSnum() {
		return SSnum;
	}

	public ArrayList<CompletedCourse> getCoursesCompleted() {
		return coursesCompleted;
	}

	public void completeCourse(Course c, Grade g) { // FIX METHOD

		coursesCompleted.add(new CompletedCourse(c.getCourseID(), c.getDescription(), c.getNumCredits(), c.getDptID(),
				super.getID(), g, new GregorianCalendar()));

		// Recalculate the credits and GPA

		setCreditsEarned(c.getNumCredits()); // ?????????????
	}
	/*
	 * private static USState getStateCode(String state){ for (USState theState
	 * : USState.values()){ if (theState.name().equalsIgnoreCase(state)){ return
	 * theState;
	 */

	/*
	 * Double GPA = null; for (Grade grade : Grade.values()) { if
	 * (grade.name().equalsIgnoreCase(g)) { GPA = grade.getGradeAmt(); } }
	 * setGPA(GPA); // NOT SURE IF THIS IS HOW YOU ACCESS THE GRADE // ENUM
	 * VALUE!
	 * 
	 * }
	 */

	public CompletedCourse findCompletedCourse(String courseID) {

		for (CompletedCourse findCourse : coursesCompleted) {

			if (findCourse.getCourseID().equalsIgnoreCase(courseID)) {
				// Return a deep copy
				return new CompletedCourse(findCourse.getCourseID(), findCourse.getDescription(),
						findCourse.getNumCredits(), findCourse.getDptID(), findCourse.getStudentID(),
						findCourse.getGrade(), findCourse.getCompletedDate());
			} else {
				throw new NoSuchElementException();
			}
		}
		return null;
	}

	public Grade getGradeofCourse(String courseID) {

		for (CompletedCourse findGrade : coursesCompleted) {
			if (findGrade.getCourseID().equalsIgnoreCase(courseID)) {
				return findGrade.getGrade();
			}
		}
		return null;
	}

	public ArrayList<CompletedCourse> getCoursesbyDepartment(String departmentID) {

		ArrayList<CompletedCourse> dptCourses = new ArrayList<CompletedCourse>();

		for (CompletedCourse returnCourse : coursesCompleted) {
			if (returnCourse.getDptID().equalsIgnoreCase(departmentID)) {

				dptCourses.add(returnCourse);
			}
		}
		return dptCourses;

	}

	public ArrayList<CompletedCourse> getCoursesbyGrade(Grade g) {
		ArrayList<CompletedCourse> getByGrade = new ArrayList<CompletedCourse>();

		for (CompletedCourse findGrade : coursesCompleted) {
			if (findGrade.getGrade() == g) {
				getByGrade.add(findGrade);
			}
		}
		return getByGrade;

	}

	/*
	 * Implement the following additional methods void CompleteCourse(Course c,
	 * Grade g) This method should Instantiate a new CompletedCourse Add this
	 * CompletedCourse to the ArrayList of CompletedCourses Recalculate the
	 * creditsEarned and GPA of this Student based on the Grade earned for the
	 * Course �c� and the number of credits of Course �c�
	 * 
	 * CompletedCourse findCompletedCourse (String courseID) return a deep copy
	 * of CompletedCourse with given CourseID. Throw NotFoundException if course
	 * wasn�t completed
	 * 
	 * Grade getGradeofCourse(String courseID) return the Grade earned for
	 * completedCourse with given CourseID
	 * 
	 * ArrayList<CompletedCourse> getCoursesbyDepartment(String departmentID)
	 * return a list of CompletedCourses that were offered by the departmentID
	 * 
	 * ArrayList<CompletedCourse> getCoursesbyGrade(Grade g) Return a list of
	 * CompletedCourses in which Student earned the specific Grade.
	 */

	@Override
	public String toString() { // FIX TO STRINGBUFFER
		return "Student [studentMajor=" + studentMajor + ", enrolledDate=" + enrolledDate + ", dateOfBirth="
				+ dateOfBirth + ", GPA=" + GPA + ", creditsEarned=" + creditsEarned + ", SSnum=" + SSnum + "]";
	}

}
