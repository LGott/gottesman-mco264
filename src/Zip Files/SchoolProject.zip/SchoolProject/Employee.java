package SchoolProject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class Employee extends Person {

	private GregorianCalendar hireDate;
	private GregorianCalendar dateOfBirth; // GregorianCalendar dataType or
											// String?
	private EmployeeType type;
	private Major major;

	// Constructor inherited from superclass
	public Employee(Integer ID, String firstName, String lastName, String midInitial, Address address,
			String phoneNumber, char gender, GregorianCalendar hireDate, GregorianCalendar dateOfBirth,
			EmployeeType type, Major major) {

		super(ID, firstName, lastName, midInitial, address, phoneNumber, gender);

		// To validate if Employee type entered actually exists
		EmployeeType typeEntered = getType(type);

		if (typeEntered == null) {
			throw new InvalidDataException(); // If type does not exist, throw
												// an exception
		}

		this.type = type;
		this.hireDate = new GregorianCalendar(); // Set hire date with todays
		this.major = major; // date

		// If date of birth is earlier than the hire date, throw an exception
		if (dateOfBirth.compareTo(this.hireDate) > 0) {
			throw new InvalidDataException();
		}

		// Create a date instance that is 18 years ago for comparison sake
		GregorianCalendar eighteen = new GregorianCalendar();
		eighteen.add(Calendar.YEAR, -18);

		// If date of birth is later than 18 years ago, the person may not be
		// hired.
		if (dateOfBirth.compareTo(eighteen) > 0) {
			System.out.println("Sorry, Employee is too young to be hired.");
			throw new InvalidDataException();
		}
		// If all validation passes, assign dateOfBirth to the variable.
		this.dateOfBirth = dateOfBirth;
	}

	// Omit the optional data
	public Employee(Integer ID, String firstName, String lastName, Address address, char gender,
			GregorianCalendar hireDate, GregorianCalendar dateOfBirth, EmployeeType type) {
		this(ID, firstName, lastName, null, address, null, gender, hireDate, dateOfBirth, type, null);

	}

	// To validate if the EmplyeeType entered exists

	private static EmployeeType getType(EmployeeType type) {
		for (EmployeeType theType : EmployeeType.values()) {
			if (theType == (type)) {
				return theType;
			}
		}
		return null;
	}

	// Getters and setters. Only employeeType may be modified

	public EmployeeType getType() {
		return type;
	}

	public void setType(EmployeeType type) {
		this.type = type;
	}

	@Override
	public Integer getID() {
		return super.getID();
	}

	public GregorianCalendar getHireDate() {
		return hireDate;
	}

	public GregorianCalendar getDateOfBirth() {
		return dateOfBirth;
	}

	public Major getMajor() {
		return this.major;
	}

	@Override
	public String toString() { // SWITCH TO STRINGBUFFER
		SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");

		return "\nhireDate: " + format.format(hireDate.getTime()) + "\n dateOfBirth: "
				+ format.format(dateOfBirth.getTime()) + " \ntype: " + type + "\n";
	}

}
