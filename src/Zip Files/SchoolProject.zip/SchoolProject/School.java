package SchoolProject;

import java.io.File;
import java.io.FileNotFoundException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.GregorianCalendar;
import java.util.Scanner;

public class School {

	private String schoolName;
	private Address address;
	private String phoneNumber;

	private ArrayList<Person> people; // to store references to instances of
										// Students
	// and Teachers,

	private ArrayList<Course> courses; // to store references to each Course the
										// School
	// may offer

	private ArrayList<Department> departments; // to store references to each
												// Departmen in the School

	public School(String schoolName, Address address, String phoneNumber) {
		this.schoolName = schoolName;
		this.address = address;
		this.phoneNumber = phoneNumber;

		people = new ArrayList<Person>();
		courses = new ArrayList<Course>();
		departments = new ArrayList<Department>();
	}

	public School(String schoolName, Address address, String phoneNumber, String teachFileName, String studentFileName,
			String departmentFileName, String courseFileName) throws ParseException, FileNotFoundException {

		this(schoolName, address, phoneNumber);

		// Read in the teacher file
		Scanner fileReader = new Scanner((new File(teachFileName)));

		/*
		 * while (fileReader.hasNext()) {
		 * 
		 * Integer ID = fileReader.nextInt(); String first = fileReader.next();
		 * String last = fileReader.next(); fileReader.next(); String street =
		 * fileReader.nextLine(); String[] cityState =
		 * fileReader.nextLine().split(","); String city = cityState[0]; String
		 * zip = fileReader.next(); String phone = fileReader.next(); char
		 * gender = fileReader.next().charAt(0); String hireDate =
		 * fileReader.next(); String birthDate = fileReader.next(); String type
		 * = fileReader.next(); String dptCode = fileReader.next(); String ssNum
		 * = fileReader.next(); String degree = fileReader.next(); String major
		 * = fileReader.next(); Double salary = fileReader.nextDouble();
		 * 
		 * // Get the enum values and validate USState state =
		 * getState(cityState); EmployeeType typeEmp = getType(type); Degree
		 * degreeType = getDegree(degree); Major majorType = getMajor(major);
		 * 
		 * // Convert date to GragorianCalendar
		 * 
		 * GregorianCalendar dateHire = stringToDate(hireDate);
		 * GregorianCalendar dateBirth = stringToDate(birthDate);
		 * 
		 * // Add a new instance of teacher to the people array (Depending on //
		 * phone number since some don't have). Major automatically gets //
		 * translated into UDCD if not entered
		 * 
		 * if (phone.equalsIgnoreCase("N/A")) { people.add(new Teacher(ID,
		 * first, last, (new Address(street, city, state, zip)), null, gender,
		 * dateHire, dateBirth, typeEmp, majorType, dptCode, ssNum, degreeType,
		 * salary)); } if (!(phone.equalsIgnoreCase("N/A"))) { people.add(new
		 * Teacher(ID, first, last, (new Address(street, city, state, zip)),
		 * phone, gender, dateHire, dateBirth, typeEmp, majorType, dptCode,
		 * ssNum, degreeType, salary)); } }
		 */

		fileReader = new Scanner(new File(studentFileName));

		while (fileReader.hasNext()) {

			Integer ID = fileReader.nextInt();
			String first = fileReader.next();
			String last = fileReader.next();
			String mid = fileReader.nextLine();
			String street = fileReader.nextLine();
			String[] cityState = fileReader.nextLine().trim().split(",");
			String city = cityState[0];
			String zip = fileReader.nextLine();
			String phone = fileReader.next();
			char gender = fileReader.next().charAt(0);
			String major = fileReader.nextLine();
			String birthDate = fileReader.next();
			String enrolledDate = fileReader.next();
			String ssNum = fileReader.next();

			// Get the enum values and validate
			USState state = getState(cityState);
			Major majorID = getMajor(major);

			// Convert date to GragorianCalendar

			GregorianCalendar dateEnrolled = stringToDate(enrolledDate);
			GregorianCalendar dateBirth = stringToDate(birthDate);

			people.add(new Student(ID, first, last, mid, (new Address(street, city, state, zip)), phone, gender,
					majorID, dateBirth, dateEnrolled, ssNum));

		}

		fileReader = new Scanner((new File(departmentFileName)));

		while (fileReader.hasNext()) {
			String departmentInfo = fileReader.nextLine();
			String[] splitInfo = departmentInfo.split(";");

			departments.add(
					new Department(splitInfo[0], splitInfo[1], splitInfo[2], splitInfo[3], splitInfo[4], splitInfo[5]));
		}

		fileReader = new Scanner((new File(courseFileName)));

		while (fileReader.hasNext()) {
			String coursesInfo = fileReader.nextLine();
			String[] splitInfo = coursesInfo.split(";");

			departments.add(
					new Department(splitInfo[0], splitInfo[1], splitInfo[2], splitInfo[3], splitInfo[4], splitInfo[5]));
		}

	}

	public USState getState(String state) {

		for (USState st : USState.values()) {
			if (st.name().equalsIgnoreCase(state)) {
				return st;
			}
		}
		return null;
	}

	public USState getState(String[] cityState) {

		for (USState st : USState.values()) {
			if (st.name().equalsIgnoreCase(cityState[1].trim())) {
				return st;
			}
		}
		return null;
	}

	public EmployeeType getType(String type) {

		for (EmployeeType et : EmployeeType.values()) {
			if (et.name().equalsIgnoreCase(type)) {
				return et;
			}
		}
		return null;

	}

	public Degree getDegree(String degree) {

		for (Degree dg : Degree.values()) {
			if (dg.name().equalsIgnoreCase(degree)) {
				return dg;
			}
		}
		return null;
	}

	public Major getMajor(String major) {

		for (Major mj : Major.values()) {
			if (mj.name().equalsIgnoreCase(major)) {
				return mj;

			}
		}
		return null;
	}

	public GregorianCalendar stringToDate(String date) {

		String[] parts = date.split("/");
		int month = Integer.parseInt(parts[0]);
		int day = Integer.parseInt(parts[1]);
		int year = Integer.parseInt(parts[2]);
		GregorianCalendar newDate = new GregorianCalendar(day, month - 1, year);
		return newDate;
	}

	// Getters and setters- PhoneNumber may be modified
	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getSchoolName() {
		return schoolName;
	}

	public Address getAddress() {
		return address;
	}

	public ArrayList<Person> getPeople() {
		return people;
	}

	public ArrayList<Course> getCourses() {
		return courses;
	}

	public ArrayList<Department> getDepartments() {
		return departments;
	}

	@Override
	public String toString() {
		return "School [schoolName=" + schoolName + ", address=" + address + ", phoneNumber=" + phoneNumber
				+ ", people=" + people + ", courses=" + courses + ", departments=" + departments + "]";
	}

	// Add a teacher based on the different constructors for the different data
	// options
	public void addTeacher(Integer ID, String firstName, String lastName, String midInitial, Address address,
			String phoneNumber, char gender, GregorianCalendar hireDate, GregorianCalendar dateOfBirth,
			EmployeeType type, String departmentID, String SSnum, Degree degree, Major majorID, Double salary) {

		if (midInitial.equalsIgnoreCase("N/A")) {
			people.add(new Teacher(ID, firstName, lastName, midInitial, address, null, gender, type, dateOfBirth,
					hireDate, majorID, departmentID, SSnum, degree, salary));
		}
		if (midInitial.equalsIgnoreCase("N/A")) {
			people.add(new Teacher(ID, firstName, lastName, null, address, phoneNumber, gender, type, dateOfBirth,
					hireDate, majorID, departmentID, SSnum, degree, salary));
		}
		if ((!((midInitial.equalsIgnoreCase("N/A"))) && (!(midInitial.equalsIgnoreCase("N/A"))))) {
			people.add(new Teacher(ID, firstName, lastName, midInitial, address, phoneNumber, gender, type, dateOfBirth,
					hireDate, majorID, departmentID, SSnum, degree, salary));
		}
	}

	// Add a student using the different constructors for the different options
	// for data entry
	public void addStudent(Integer ID, String firstName, String lastName, String midInitial, Address address,
			String phoneNumber, char gender, Major studentMajor, GregorianCalendar dateOfBirth,
			GregorianCalendar dateEnrolled, String SSnum) {

		// Major automatically gets translated into UDCD if not entered

		if (phoneNumber == null) {

			people.add(new Student(ID, firstName, lastName, midInitial, address, gender, studentMajor, dateOfBirth,
					dateEnrolled, SSnum));
		}

		if (midInitial == null) {
			people.add(new Student(ID, firstName, lastName, address, gender, studentMajor, dateOfBirth, dateEnrolled,
					SSnum));
		}

		if ((phoneNumber != null) && (midInitial != null)) {
			people.add(new Student(ID, firstName, lastName, midInitial, address, phoneNumber, gender, studentMajor,
					dateOfBirth, dateEnrolled, SSnum));
		}
	}

	// Add a course
	public void addCourse(String courseID, String description, int numCredits, String dptID) {

		courses.add(new Course(courseID, description, numCredits, dptID));
	}

	// Add a department
	public void addDepartment(String departmentID, String departmentName, String location, String phoneNumber,
			String faxNumber, String departmentChairperson) {

		departments.add(
				new Department(departmentID, departmentName, location, phoneNumber, faxNumber, departmentChairperson));
	}

	public ArrayList<Person> displayPeople() {
		ArrayList<Person> deepCopy = new ArrayList<Person>();
		for (Person person : people) {
			deepCopy.add(person);
		}
		return deepCopy;

	}

	// remove a teacher
	public void removeTeacher(String firstName, String lastName) {

		for (Person removeTeacher : people) {
			if (removeTeacher instanceof Teacher) {

				if (removeTeacher.getLastName().equalsIgnoreCase(lastName)
						&& removeTeacher.getFirstName().equalsIgnoreCase(firstName)) {

					people.remove(removeTeacher);

				}

			}
		}
	}

	// remove a student
	public void removeStudent(String firstName, String lastName) {
		for (Person removeStudent : people) {
			if (removeStudent instanceof Student) {

				if (removeStudent.getLastName().equalsIgnoreCase(lastName)
						&& removeStudent.getFirstName().equalsIgnoreCase(firstName)) {

					people.remove(removeStudent);

				}

			}
		}

	}

	// remove a course
	public void removeCourse(String course) {
		for (Course removeCourse : courses) {

			if (removeCourse.getCourseID().equalsIgnoreCase(course)) {

				people.remove(removeCourse);

			}

		}
	}

	// Modify the teacher last name
	public void modifyTeacherLastName(Integer teacherID, String newLastName) {

		for (Person modifyTeacher : people) {
			if (modifyTeacher instanceof Teacher) {

				if (modifyTeacher.getID() == (teacherID)) {

					modifyTeacher.setLastName(newLastName);

				}
			}
		}
	}

	// modify the teacher address
	public void modifyTeacherAddress(Integer teacherID, Address address) {

		for (Person teacher : people) {
			if (teacher instanceof Teacher) {

				if (teacher.getID() == (teacherID)) {

					teacher.setAddress(address);

				}
			}
		}
	}

	// modify the teacher degree
	public void modifyTeacherDegree(Integer teacherID, Degree degree, Major major) {

		for (Person modifyDegree : people) {
			if (modifyDegree instanceof Teacher) {

				if (modifyDegree.getID() == (teacherID)) {

					((Teacher) modifyDegree).setDegree(degree);
					((Teacher) modifyDegree).setMajorID(major);

				}
			}
		}
	}

	// Give the teacher a raise (percent)
	public void giveTeacherRaise(Integer teacherID, Double percent) {

		for (Person teacher : people) {
			if (teacher instanceof Teacher) {

				if (teacher.getID() == (teacherID)) {

					((Teacher) teacher).applyRaise(percent);
				}
			}
		}
	}

	// Give the teacher a raise (salary amount)
	public void giveTeacherRaise2(Integer teacherID, Double amount) {

		for (Person teacher : people) {
			if (teacher instanceof Teacher) {

				if (teacher.getID() == (teacherID)) {

					((Teacher) teacher).setSalary(amount);
				}
			}
		}
	}

	// modify student last name
	public void modifyStudentLastName(Integer studentID, String newLastName) {

		for (Person modifyStudent : people) {
			if (modifyStudent instanceof Student) {

				if (modifyStudent.getID() == (studentID)) {

					modifyStudent.setLastName(newLastName);

				}
			}
		}
	}

	// modify student number

	public void modifyStudentPhoneNumber(Integer studentID, String newPhoneNumber) {

		for (Person modifyStudent : people) {
			if (modifyStudent instanceof Student) {

				if (modifyStudent.getID() == (studentID)) {

					modifyStudent.setLastName(newPhoneNumber);

				}
			}
		}
	}

	// add a completed course to the arrayList
	public void addCompletedCourse(Integer studentID, String courseID, Grade grade) {

		for (Course findCourse : courses) {

			if (findCourse.getCourseID().equalsIgnoreCase(courseID)) {

				for (Person student : people) {
					if (student instanceof Student) {
						if (student.getID() == studentID) {

							((Student) student).completeCourse(findCourse, grade);
						}
					}
				}
			}
		}
	}

	public Double getStudentGPA(Integer studentID) {

		for (Person student : people) {
			if (student instanceof Student) {

				if (student.getID() == (studentID)) {

					return ((Student) student).getGPA();

				}
			}
		}
		return null;
	}

	public Grade getGradeofCourse(Integer studentID, String courseID) {

		for (Person student : people) {
			if (student instanceof Student) {
				if (student.getID() == studentID) {

					return ((Student) student).getGradeofCourse(courseID);
				}
			}
		}
		return null;
	}

	// return a list of CompletedCourses that were offered by the departmentID
	// and completed by student with id, studentID

	public ArrayList<CompletedCourse> getCoursesbyDepartment(Integer studentID, String departmentID) {

		for (Person student : people) {
			if (student instanceof Student) {
				if (student.getID() == studentID) {

					return ((Student) student).getCoursesbyDepartment(departmentID);

				}
			}
		}
		return null;
	}

	// Return a list of CompletedCourses in which Student with id, studentID,
	// earned the specificGrade.

	public ArrayList<CompletedCourse> getCoursesbyGrade(Integer studentID, Grade g) {

		for (Person student : people) {
			if (student instanceof Student) {
				if (student.getID() == studentID) {

					return ((Student) student).getCoursesbyGrade(g);

				}
			}
		}
		return null;
	}

	// return a list of Teachers sorted by lastname, firstname

	public ArrayList<Teacher> getTeachersSortedByName() {

		ArrayList<Teacher> sortedTeachers = new ArrayList<Teacher>();

		for (Person teacher : people) {
			if (teacher instanceof Teacher) {

				sortedTeachers.add((Teacher) teacher);

				Collections.sort(sortedTeachers, new TeacherComparator());
			}
		}
		return sortedTeachers;
	}

	// return list of Teachers sorted by teacherid

	public ArrayList<Teacher> getTeachers() {

		ArrayList<Teacher> sortedTeachers = new ArrayList<Teacher>();

		for (Person teacher : people) {
			if (teacher instanceof Teacher) {

				sortedTeachers.add((Teacher) teacher);

				Collections.sort(sortedTeachers, new TeacherComparatorID());
			}
		}

		return sortedTeachers;
	}

	// return list of Students sorted by studentid

	public ArrayList<Student> getStudents() {

		ArrayList<Student> sortedStudents = new ArrayList<Student>();

		for (Person student : people) {
			if (student instanceof Student) {

				sortedStudents.add((Student) student);

				Collections.sort(sortedStudents, new StudentComparatorID());
			}
		}

		return sortedStudents;
	}

	// return list of Students sorted by lastname, firstname

	public ArrayList<Student> getStudentsByName() {
		ArrayList<Student> sortedStudents = new ArrayList<Student>();

		for (Person student : people) {
			if (student instanceof Student) {

				sortedStudents.add((Student) student);

				Collections.sort(sortedStudents, new StudentComparatorName());
			}
		}

		return sortedStudents;
	}

	// Add a taught Course
	public void addTaughtCourse(Integer teacherID, String courseID, Integer year, Semester semester, Section section) {

		for (Person teacher : people) {
			if (teacher instanceof Teacher) {

				if (teacher.getID() == (teacherID)) {

					for (Course course : courses) {
						if (course.getCourseID().equalsIgnoreCase(courseID)) {

							((Teacher) teacher).taughtCourse(course, year, semester, section);
						}
					}
				}
			}
		}
	}

	// Find out how many courses a teacher teaches in a semester
	public int howManyCoursesPerSemester(Integer teacherID, Integer year, Semester semester) {

		for (Person teacher : people) {
			if (teacher instanceof Teacher) {

				if (teacher.getID() == (teacherID)) {

					return ((Teacher) teacher).howManyCoursesPerSemester(year, semester);
				}
			}
		}
		return -1;
	}
}
