package SchoolProject;

public class Person {

	private Integer ID;
	private String firstName;
	private String lastName;
	private String midInitial;
	private Address address;
	private String phoneNumber;
	private char gender;

	// Constructor that uses all data fields

	public Person(Integer ID, String firstName, String lastName, String midInitial, Address address, String phoneNumber,
			char gender) {
		this.ID = ID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.midInitial = midInitial;
		this.address = address;
		this.gender = gender;

		// Data Validation for Phone number
		if (phoneNumber == null) {
			this.phoneNumber = null;
		}
		if (!(this.phoneNumber == null)) {
			if (isValid(phoneNumber) == true) {
				this.phoneNumber = phoneNumber;
			} else {
				throw new InvalidDataException();
			}
		}

	}

	// Constructor that omits the optional data fields
	public Person(String firstName, String lastName, Address address, char gender) {
		this(null, firstName, lastName, null, address, null, gender);
	}

	public boolean isValid(String phoneNumber) {
		if (phoneNumber.length() == 10) {
			return true;
		} else {
			return false;
		}
	}
	// Getters and Setters. Only Last name, address, and phone number may be
	// modified

	public Integer getID() {
		return ID;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMidInitial() {
		return midInitial;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public char getGender() {
		return gender;
	}

	@Override
	public String toString() { // FIX THIS TO STRINGBUFFER
		return "Person [ID=" + ID + ", firstName=" + firstName + ", lastName=" + lastName + ", midInitial=" + midInitial
				+ ", address=" + address + ", phoneNumber=" + phoneNumber + ", gender=" + gender + "]";
	}

	// CompareTo method based on ID
	public int compareTo(Person other) {
		return ID.compareTo(other.getID());
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (prime * result) + ((ID == null) ? 0 : ID.hashCode());
		return result;
	}

	// Equals method based on ID
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Person other = (Person) obj;
		if (ID == null) {
			if (other.ID != null) {
				return false;
			}
		} else if (!ID.equals(other.ID)) {
			return false;
		}
		return true;
	}

}
