package SchoolProject;

import java.util.ArrayList;
import java.util.GregorianCalendar;

public class Teacher extends Employee {

	private String departmentID;
	private String SSnum;
	private Degree degree;
	private Major majorID;
	private Double salary;
	private ArrayList<ToughtCourse> toughtCourses;

	public Teacher(Integer ID, String firstName, String lastName, Address address, String phoneNumber, char gender,
			GregorianCalendar hireDate, GregorianCalendar dateOfBirth, EmployeeType type, Major majorID,
			String departmentID, String SSnum, Degree degree, Double salary) {

		super(ID, firstName, lastName, null, address, phoneNumber, gender, hireDate, dateOfBirth, type, majorID);

		this.departmentID = departmentID;
		this.SSnum = SSnum;
		this.degree = degree;

		if (getDegree(degree) == null) {
			throw new InvalidDataException(); // If degree does not exist, throw
												// an exception
		}

		this.majorID = majorID;

		if (getMajor(majorID) == null) {
			System.out.println("Non-Existent Major.");
			throw new InvalidDataException(); // If major does not exist, throw
												// an exception
		}

		// If salary is an unreasonable amount, throw an exception
		if ((salary >= 10000) && (salary <= 100000)) {
			this.salary = salary;
		}

		else {
			System.out.println("Invalid salary amount entered.");
			throw new InvalidDataException();
		}

		this.toughtCourses = new ArrayList<ToughtCourse>();
	}

	// Constructor that takes the mid initial
	public Teacher(Integer ID, String firstName, String lastName, String midInitial, Address address,
			String phoneNumber, char gender, EmployeeType type, GregorianCalendar hireDate,
			GregorianCalendar dateOfBirth, Major majorID, String departmentID, String SSnum, Degree degree,
			Double salary) {

		this(ID, firstName, lastName, address, phoneNumber, gender, hireDate, dateOfBirth, type, majorID, departmentID,
				SSnum, degree, salary);

	}

	// Constructor that omits the phone Number
	public Teacher(Integer ID, String firstName, String midInitial, String lastName, Address address, char gender,
			EmployeeType type, GregorianCalendar hireDate, GregorianCalendar dateOfBirth, String departmentID,
			String SSnum, Degree degree, Major majorID, Double salary) {

		this(ID, firstName, lastName, address, null, gender, hireDate, dateOfBirth, type, majorID, departmentID, SSnum,
				degree, salary);

	}

	// For major validation
	private static Major getMajor(Major major) {
		for (Major theMajor : Major.values()) {
			if (theMajor == (major)) {
				return theMajor;
			}
		}
		return null;
	}

	// To validate if the degree entered exists

	private static Degree getDegree(Degree degree) {
		for (Degree theDegree : Degree.values()) {
			if (theDegree == (degree)) {
				return theDegree;
			}
		}
		return null;
	}

	// only Degree, Major, and salary may be modified

	public void setDegree(Degree degree) {
		this.degree = degree;
	}

	public void setMajorID(Major majorID) {
		this.majorID = majorID;
	}

	public void setSalary(Double salary) {
		this.salary = salary;
	}

	public String getDepartmentID() {
		return departmentID;
	}

	public String getSSnum() {
		return SSnum;
	}

	public Degree getDegree() {
		return degree;
	}

	public Major getMajorID() {
		return majorID;
	}

	public Double getSalary() {
		return salary;
	}

	public ArrayList<ToughtCourse> getToughtCourses() {
		return toughtCourses;
	}

	@Override
	public String toString() {

		StringBuffer buffer = new StringBuffer();

		buffer.append("Teacher ID: ");
		buffer.append(super.getID());
		buffer.append("Teacher Name: ");
		buffer.append(super.getFirstName() + " " + super.getLastName());
		buffer.append(super.getAddress() + "\n");
		buffer.append("Teacher Gender :");
		buffer.append(super.getGender() + " ");
		buffer.append(super.toString());
		buffer.append("Teacher Major :");
		buffer.append(getMajorID());
		buffer.append("\nTeacher Department: ");
		buffer.append(getDepartmentID());
		buffer.append("\nTeacher SSN:");
		buffer.append(getSSnum());
		buffer.append("\nTeacher Degree: ");
		buffer.append(getDegree());
		buffer.append("\nTeacher Salary:");
		buffer.append(getSalary() + "\n\n");

		return buffer.toString();
	}

	public void applyRaise(Double percent) {
		this.salary += salary * percent;
	}

	public void taughtCourse(Course c, Integer year, Semester semester, Section sectionID) {

		Semester theSemester = null;
		for (Semester findSemester : Semester.values()) { // Do I need this
															// whole loop or its
															// extra???
			if (findSemester == semester) {
				theSemester = findSemester;
			}
		}

		Section theSection = null;
		for (Section findSection : Section.values()) { // Do I need this whole
														// loop or its extra???
			if (findSection == sectionID) {
				theSection = findSection;
			}
		}

		// Add validation to see if the array already has this course
		toughtCourses.add(new ToughtCourse(c.getCourseID(), c.getDescription(), c.getNumCredits(), c.getDptID(),
				super.getID(), year, theSemester, theSection));
	}

	public int howManyCoursesPerSemester(Integer year, Semester semesterID) {

		int courseCount = 0;

		for (ToughtCourse courseAmt : toughtCourses) {
			if ((courseAmt.getYear() == year) && (courseAmt.getSemesterID() == semesterID)) {
				courseCount++;
			}
		}
		return courseCount;
	}

	public int howManyDifferentCourses() {

		int difCourseCount = 0;

		for (ToughtCourse difCourse : toughtCourses) {
			for (ToughtCourse otherCourse : toughtCourses) {
				if (difCourse.getCourseID().equalsIgnoreCase(otherCourse.getCourseID())) {
					difCourseCount++;
				}
			}
		}
		return difCourseCount;
	}

	/*
	 * public int compareTo(Teacher compareTeachers) {
	 * 
	 * String compareLastName = compareTeachers.getLastName();
	 * 
	 * return //descending order //return compareQuantity - this.quantity;
	 * 
	 * }
	 * 
	 * public static Comparator<Fruit> FruitNameComparator = new
	 * Comparator<Fruit>() {
	 * 
	 * public int compare(Fruit fruit1, Fruit fruit2) {
	 * 
	 * String fruitName1 = fruit1.getFruitName().toUpperCase(); String
	 * fruitName2 = fruit2.getFruitName().toUpperCase();
	 * 
	 * //ascending order return fruitName1.compareTo(fruitName2);
	 * 
	 * //descending order //return fruitName2.compareTo(fruitName1); }
	 * 
	 * }; }
	 */

}
