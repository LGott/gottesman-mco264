package SchoolProject;

public enum Section {
	BA,BB,BC, FA, FB,FD, OL,FC, FE;
}
