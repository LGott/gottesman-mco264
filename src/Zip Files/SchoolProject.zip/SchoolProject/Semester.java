package SchoolProject;

public enum Semester {
	FALL, SPRING, SUMMER1, SUMMER2;
}
