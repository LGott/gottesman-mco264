package SchoolProject;

public class ToughtCourse extends Course {

	private String dptID;
	private Integer teacherID;
	private Integer year;
	private Semester semesterID;
	private Section sectionID;

	public ToughtCourse(String courseID, String description, int numCredits, String dptID, Integer teacherID,
			Integer year, Semester semesterID, Section sectionID) {

		super(courseID, description, numCredits, dptID);

		this.dptID = dptID;
		this.teacherID = teacherID;
		this.year = year;
		this.semesterID = semesterID;
		this.sectionID = sectionID;

	}

	@Override
	public String getDptID() {
		return dptID;
	}

	public Integer getTeacherID() {
		return teacherID;
	}

	public Integer getYear() {
		return year;
	}

	public Semester getSemesterID() {
		return semesterID;
	}

	public Section getSectionID() {
		return sectionID;
	}

	@Override
	public String toString() {
		return "ToughtCourse [dptID=" + dptID + ", teacherID=" + teacherID + ", year=" + year + ", semesterID="
				+ semesterID + ", sectionID=" + sectionID + "]";
	}

}
