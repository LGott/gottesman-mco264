package SchoolProject;

public enum Degree {
	BA,BS, MA,MS,Phd,CPA;
}
