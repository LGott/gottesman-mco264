package SchoolProject;

public class InvalidPhoneNumberException extends Exception {
 public InvalidPhoneNumberException(){
	 super("Invalid amount of digits entered.");
 }
}
