package SchoolProject;

public class Course {

	/*
	 * CourseID, Description, NumCredits, DepartmentID Implement constructor.
	 * NumCredits must be a reasonable amount � 0-4 is one possible range of
	 * values Implement getters Implement toString () method Implement compareTo
	 * and equals methods , two instances of Course are compared based on the
	 * CourseID
	 */

	private String courseID;
	private String description;
	private int numCredits;
	private String dptID;

	public Course(String courseID, String description, int numCredits, String dptID) {

		this.courseID = courseID;
		this.description = description;

		if ((numCredits < 1) || (numCredits > 4)) {
			throw new InvalidDataException();
		}
		this.numCredits = numCredits;
		this.dptID = dptID;

	}

	@Override
	public String toString() {
		return "Course [courseID=" + courseID + ", description=" + description + ", numCredits=" + numCredits
				+ ", dptID=" + dptID + "]";
	}

	public String getCourseID() {
		return courseID;
	}

	public String getDescription() {
		return description;
	}

	public int getNumCredits() {
		return numCredits;
	}

	public String getDptID() {
		return dptID;
	}

	public int compareTo(Course otherCourse) {
		return courseID.compareTo(otherCourse.getCourseID());
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (prime * result) + ((courseID == null) ? 0 : courseID.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Course other = (Course) obj;
		if (courseID == null) {
			if (other.courseID != null) {
				return false;
			}
		} else if (!courseID.equals(other.courseID)) {
			return false;
		}
		return true;
	}

}