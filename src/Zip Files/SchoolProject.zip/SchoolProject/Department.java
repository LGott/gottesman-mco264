package SchoolProject;

public class Department {

	String departmentID;
	String departmentName;
	String location;
	String phoneNumber;
	String faxNumber;
	String departmentChairperson;

	public Department(String departmentID, String departmentName, String location, String phoneNumber, String faxNumber,
			String departmentChairperson) {

		this.departmentID = departmentID;
		this.departmentName = departmentName;
		this.location = location;

		// validate phone number
		if (isValid(this.phoneNumber)) {
			this.phoneNumber = phoneNumber;
		} else {
			throw new InvalidDataException();
		}

		this.faxNumber = faxNumber;
		this.departmentChairperson = departmentChairperson;
	}

	// A constructor that omits the extra data

	public Department(String departmentName) {

		this(null, departmentName, null, null, null, null);
	}

	// Validation for phone number
	public boolean isValid(String phoneNumber) {
		if (phoneNumber.length() == 10) {
			return true;
		} else {
			return false;
		}
	}

	// Getters and Setters. Department name may not be modified
	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getFaxNumber() {
		return faxNumber;
	}

	public void setFaxNumber(String faxNumber) {
		this.faxNumber = faxNumber;
	}

	public String getDepartmentChairperson() {
		return departmentChairperson;
	}

	public void setDepartmentChairperson(String departmentChairperson) {
		this.departmentChairperson = departmentChairperson;
	}

	public String getDepartmentID() {
		return departmentID;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public int compareTo(Department other) {
		return departmentID.compareTo(other.departmentID);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = (prime * result) + ((departmentID == null) ? 0 : departmentID.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		Department other = (Department) obj;
		if (departmentID == null) {
			if (other.departmentID != null) {
				return false;
			}
		} else if (!departmentID.equals(other.departmentID)) {
			return false;
		}
		return true;
	}

}
