package pharmaceuticalCo;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.RandomAccessFile;
import java.io.Serializable;
import java.util.ArrayList;

public class PharmacyList implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	ArrayList<CompanyCodeIndex> compCodes;
	ArrayList<CompanyNameIndex> compNames;
	RandomAccessFile raFile;
	PharmaceuticalCo pharmCo;

	public PharmacyList() throws FileNotFoundException {

		compCodes = new ArrayList<CompanyCodeIndex>();
		compNames = new ArrayList<CompanyNameIndex>();
		raFile = new RandomAccessFile(new File("./reWritePharmacies.txt"), "rw");
	}

	public void addCompany(String companyCode, String companyName, String phoneNumber)
			throws DuplicateDataException, IOException {

		pharmCo = new PharmaceuticalCo(companyCode, companyName, phoneNumber);

		Long indexLocation = pharmCo.writeToFile(raFile, raFile.length());

		// Set up two separate index records CompanyCodeIndex and
		// CompanyNameIndex ,
		// each referencing the same location in the RandomAccessFile

		CompanyCodeIndex codeIndex = new CompanyCodeIndex(companyCode, indexLocation);

		// Verify that the company does not already exist

		if (!(compCodes.contains(indexLocation))) {
			compCodes.add(codeIndex);
			// Collections.sort(compCodes);
		} else {
			throw new DuplicateDataException();
		}

		CompanyNameIndex nameIndex = new CompanyNameIndex(companyName, indexLocation);

		if (!(compNames.contains(indexLocation))) {
			compNames.add(nameIndex);
			// Collections.sort(compNames);
		} else {
			throw new DuplicateDataException();
		}

	}

	/*
	 * Search through the arraylist of code indexes and if found, retrieve
	 * location of that record, instantiate a PharmaceuticalCo record from the
	 * RandomAccessFile and return the record
	 */

	public PharmaceuticalCo findCompanyCode(String companyCode) throws IOException, NotFoundException {

		for (CompanyCodeIndex index : compCodes) {
			if (companyCode.equalsIgnoreCase(index.getCompanyCode())) {
				if ((index.isActive())) { // IS THIS HOW U DO IT?

					PharmaceuticalCo pharmCo = new PharmaceuticalCo(raFile, index.getLocation());
					return pharmCo;
				}
			}
		}
		System.out.println("Nonexistant or Deleted Company");
		throw new NotFoundException();

	}

	public PharmaceuticalCo findCompanyName(String companyName) throws IOException, NotFoundException {

		for (CompanyNameIndex index : compNames) {
			if (companyName.equalsIgnoreCase(index.getCompanyName())) {

				PharmaceuticalCo pharmCo = new PharmaceuticalCo(raFile, index.getLocation());
				return pharmCo;
			}
		}
		System.out.println("Nonexistant or Deleted Company");
		throw new NotFoundException();
	}

	public String displayCompanyCode(String companyCode) throws IOException, NotFoundException {

		PharmaceuticalCo pharmCo = findCompanyCode(companyCode);

		return pharmCo.toString();

	}

	public String displayCompanyName(String companyName) throws IOException, NotFoundException {

		PharmaceuticalCo pharmCo = findCompanyName(companyName);

		return pharmCo.toString();

	}

	public ArrayList<PharmaceuticalCo> displayAll() throws IOException, NotFoundException {

		ArrayList<PharmaceuticalCo> printAll = new ArrayList<PharmaceuticalCo>();

		for (CompanyCodeIndex index : compCodes) {
			if (index.isActive()) {
				PharmaceuticalCo pharmCo = new PharmaceuticalCo(raFile, index.getLocation());
				printAll.add(pharmCo);
			}
		}
		return printAll;
	}

	public void removeCompany(String companyCode) throws IOException, NotFoundException {

		PharmaceuticalCo company = findCompanyCode(companyCode);

		for (CompanyCodeIndex index : compCodes) {
			for (CompanyNameIndex index2 : compNames) {
				if (company.getCompanyCode().equalsIgnoreCase(index.getCompanyCode())) {

					compCodes.remove(index.getCompanyCode());
					compNames.remove(index2.getCompanyName());

					// index.setDeleted();

					index.setNotActive();
					index.setNotActive();
				}
			}
			// Set it to not active once its removed
			// Collections.sort(compCodes);

		}

	}
	/* Modify the phone number and re-write it to the file */

	public void modifyCompanyPhone(String companyCode, String newNumber)
			throws NotFoundException, IOException, InvalidDataException {

		for (CompanyCodeIndex index : compCodes) {
			if (companyCode.equalsIgnoreCase(index.getCompanyCode())) {
				if (!(index.isActive())) { // IS THIS HOW U DO IT?

					PharmaceuticalCo pharmCo = new PharmaceuticalCo(raFile, index.getLocation());

					pharmCo.setPhoneNumber(newNumber);
					pharmCo.writeToFile(raFile, index.getLocation());

				} else {
					throw new NotFoundException();
				}
			}

		}
	}

	public void shutdown(String indexFileName) throws FileNotFoundException, IOException {

		System.out.println("writing out to file " + indexFileName);
		ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream(indexFileName));

		System.out.println("set up reference to the file");
		output.writeObject(pharmCo);

		System.out.println("wrote out the data");
		output.close();
	}

	@Override
	public String toString() {
		StringBuffer buffer = new StringBuffer();
		buffer.append(compCodes);
		buffer.append(compNames);

		return buffer.toString();
	}

}
