package stringBag;

public class EmptyBagException extends Exception {
	public EmptyBagException() {
		super ("Bag is empty. Cannot remove anything.");
	}
}
