package stringBag;

public interface StringBagInterface {

	String chooseAtRandom();
	//Returns a string chosen at random

	void insert(String str);
	//Inserts a string into the bag

	String remove();
	//Removes the random string that was called from the random method and returns it to the user 

	void clearBag();
	//clears the bag of the contents 

	boolean isEmpty();
	//Returns true if the bag is empty

	boolean isFull();
	//Returns true if the bag is full

	int contentSize();
	//returns the amount of contents that were inserted into  the bag
}
