package stringBag;

public class StringBagTest {

	public static void main(String[] args) throws EmptyBagException {
		// TODO Auto-generated method stub

		StringBag testBag = new StringBag(5);

		testBag.insert("Good");
		testBag.insert("Night");
		testBag.insert("Pizza");

		//Check that the bag is not empty
		if (!(testBag.isEmpty())) {
			for (int i = 0; i < (testBag.contentSize()); i++) { //Print out a random removal until the bag is empty 

				String word = testBag.remove();
				if (word != null) { //If the word is null(has been removed from the bag, do not print out)
					System.out.println(word);
				}

				else {
					throw new EmptyBagException();
				}
			}

		}


	}

}


