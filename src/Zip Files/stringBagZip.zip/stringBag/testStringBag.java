package stringBag;

import org.junit.Test;

public class testStringBag {

	@Test
	public void test() {

		StringBag testBag = new StringBag();

		testBag.insert("Good");
		testBag.insert("Night");
		testBag.insert("Pizza");
		String randomWord = testBag.remove();

	}

}
