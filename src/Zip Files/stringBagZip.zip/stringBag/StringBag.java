package stringBag;

import java.util.Random;

public class StringBag implements StringBagInterface {

	private String[] bag;
	private int i;
	private int count = 0;

	public StringBag(int size) {
		// TODO Auto-generated constructor stub

		i = 0;
		bag = new String[size];
	}


	@Override
	public String chooseAtRandom() {
		// TODO Auto-generated method stub

		String random = (bag[new Random().nextInt(i)]); //Generate a random string from the bag 
		return random;
	}

	@Override
	public void insert(String str) {
		// TODO Auto-generated method stub

		bag[i] = str; //Place the string into the first position in the bag
		i++; //Increase the count
		count++;
	}

	@Override
	public String remove() {
		// TODO Auto-generated method stub

		String removed = null;
		if (i > 0) {
			removed = chooseAtRandom();
		}

		// returns the index of the random string or returns
		// or -1 if stringToRemove is not in this bag.
		int subscript = indexOf(removed);
		if (subscript == -1) {
			return "Not in Bag";
		}

		else {
			// Move the last string in the array to where the random string was found.
			bag[subscript] = bag[i - 1];

			bag[i - 1] = null;

			// Decrease this StringBag's number of elements
			i--;

			return removed;
		}
	}

	//Return the index of the the random string
	private int indexOf(String element) {

		for (int index = 0; index < i; index++) {
			if (element.equals(bag[index])) {
				return index;
			}
		}

		return -1;
	}

	@Override
	public boolean isEmpty() {
		// TODO Auto-generated method stub

		if(bag.length==0){
			return true;
		}
		else{
			return false;
		}
	}

	@Override
	public boolean isFull() {
		if (bag.length == i) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public int contentSize() {
		return this.count;
	}
	@Override
	public void clearBag() {
		// TODO Auto-generated method stub

		for (int i = 0; i < bag.length; i++) {
			bag[i] = null;
			i++;
		}

	}

}
