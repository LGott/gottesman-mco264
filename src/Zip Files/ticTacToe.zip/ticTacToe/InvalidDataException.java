package ticTacToe;

public class InvalidDataException extends RuntimeException {
	public InvalidDataException(){
		super ("invalid data");
	}

}
