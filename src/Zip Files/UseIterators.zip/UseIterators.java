package randomAccessStudentDataLLIndex;

import java.util.LinkedList;


public class UseIterators{
	

public static void main (String args[]){
	
	LinkedList<String> names = new LinkedList<String>();
	
	names.add("Libby");
	names.add("Leba");
	names.add("Rena");
	
	names.iter.reset();
	while(names.iterator().hasNext()){
		System.out.println(names.iterator().next());
	}
}
}